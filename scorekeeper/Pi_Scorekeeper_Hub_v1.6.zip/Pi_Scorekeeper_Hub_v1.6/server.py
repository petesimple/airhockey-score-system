#!/usr/bin/env python3
import json
import hmac
import base64
import ipaddress
import os
import posixpath
import queue
import secrets
import socket
import sqlite3
import threading
import time
from datetime import datetime, timezone
from http import HTTPStatus
from http.cookies import SimpleCookie
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

ROOT = Path(__file__).resolve().parent
STATIC = ROOT / "static"
APP_VERSION = "v1.6"
DB_PATH = Path(os.environ.get("SCOREKEEPER_DB", ROOT / "scorekeeper.db"))
PORT = int(os.environ.get("SCOREKEEPER_PORT", "8081"))
ADMIN_PASSWORD = os.environ.get("SCOREKEEPER_ADMIN_PASSWORD", "2580")
ADMIN_COOKIE = "scorekeeper_admin"
ADMIN_SESSION_SECONDS = 8 * 60 * 60
DISCOVERY_PORT = int(os.environ.get("SCOREKEEPER_DISCOVERY_PORT", "8082"))
subscribers: list[queue.Queue] = []
subscriber_lock = threading.Lock()
admin_sessions: dict[str, float] = {}
admin_session_lock = threading.Lock()


def db():
    connection = sqlite3.connect(DB_PATH, timeout=10)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA journal_mode=WAL")
    connection.execute("PRAGMA foreign_keys=ON")
    return connection


def initialize():
    with db() as connection:
        connection.execute("""
            CREATE TABLE IF NOT EXISTS table_state (
                table_number INTEGER PRIMARY KEY,
                device_id TEXT NOT NULL,
                player1 TEXT NOT NULL,
                player2 TEXT NOT NULL,
                score1 INTEGER NOT NULL DEFAULT 0,
                score2 INTEGER NOT NULL DEFAULT 0,
                games1 INTEGER NOT NULL DEFAULT 0,
                games2 INTEGER NOT NULL DEFAULT 0,
                game_number INTEGER NOT NULL DEFAULT 1,
                best_of INTEGER NOT NULL DEFAULT 7,
                status TEXT NOT NULL,
                payload TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
        """)
        connection.execute("""
            CREATE TABLE IF NOT EXISTS score_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                table_number INTEGER NOT NULL,
                device_id TEXT NOT NULL,
                event_type TEXT NOT NULL,
                payload TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        """)
        connection.execute("CREATE INDEX IF NOT EXISTS idx_score_events_table_created ON score_events(table_number, created_at DESC)")
        connection.execute("""
            CREATE TABLE IF NOT EXISTS match_corrections (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_id INTEGER NOT NULL,
                original_payload TEXT NOT NULL,
                corrected_payload TEXT NOT NULL,
                reason TEXT NOT NULL,
                corrected_at TEXT NOT NULL,
                FOREIGN KEY(event_id) REFERENCES score_events(id)
            )
        """)
        connection.execute("CREATE INDEX IF NOT EXISTS idx_match_corrections_event ON match_corrections(event_id, id DESC)")
        connection.execute("CREATE TABLE IF NOT EXISTS app_settings (setting_key TEXT PRIMARY KEY, setting_value TEXT NOT NULL, updated_at TEXT NOT NULL)")
        connection.execute("""
            CREATE TABLE IF NOT EXISTS match_assignments (
                table_number INTEGER PRIMARY KEY,
                player1 TEXT NOT NULL,
                player2 TEXT NOT NULL,
                match_id TEXT NOT NULL DEFAULT '',
                best_of INTEGER NOT NULL DEFAULT 7,
                source TEXT NOT NULL DEFAULT 'manual',
                referee TEXT NOT NULL DEFAULT '',
                open_url TEXT NOT NULL DEFAULT '',
                revision INTEGER NOT NULL DEFAULT 1,
                assigned_at TEXT NOT NULL
            )
        """)
        connection.execute("""
            CREATE TABLE IF NOT EXISTS player_names (
                name TEXT PRIMARY KEY COLLATE NOCASE,
                last_used_at TEXT NOT NULL
            )
        """)
        connection.execute("CREATE INDEX IF NOT EXISTS idx_player_names_recent ON player_names(last_used_at DESC)")
        connection.execute("""
            CREATE TABLE IF NOT EXISTS table_devices (
                table_number INTEGER PRIMARY KEY,
                device_id TEXT NOT NULL DEFAULT '',
                ip_address TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
        """)
        connection.execute("""
            CREATE TABLE IF NOT EXISTS assignment_receipts (
                table_number INTEGER PRIMARY KEY,
                revision INTEGER NOT NULL,
                device_id TEXT NOT NULL,
                received_at TEXT NOT NULL
            )
        """)
        connection.execute("""
            CREATE TABLE IF NOT EXISTS assignment_delivery (
                table_number INTEGER PRIMARY KEY,
                revision INTEGER NOT NULL,
                status TEXT NOT NULL,
                detail TEXT NOT NULL DEFAULT '',
                attempted_at TEXT NOT NULL
            )
        """)
        # Remove every unclaimed route left by the retired Android-tablet handoff.
        # New rows are observations from CYDs that actually contact this hub.
        connection.execute("DELETE FROM table_devices WHERE device_id = ''")
        connection.execute("PRAGMA optimize")


def now_iso():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


DEFAULT_BRANDING = {"eventTitle": "7-6 SCOREKEEPER", "subtitle": "Live view from every connected CYD", "theme": "classic", "background": "#071a2a", "panel": "#0c283e", "accent": "#d72638", "text": "#fff7e7", "logoData": ""}


def branding_settings():
    with db() as connection:
        row = connection.execute("SELECT setting_value FROM app_settings WHERE setting_key='branding'").fetchone()
    if not row:
        return dict(DEFAULT_BRANDING)
    try:
        return {**DEFAULT_BRANDING, **json.loads(row["setting_value"])}
    except (ValueError, TypeError):
        return dict(DEFAULT_BRANDING)


def clean_branding(raw):
    if not isinstance(raw, dict):
        raise ValueError("Invalid branding settings")
    def color(name, fallback):
        value = str(raw.get(name, fallback))
        if len(value) != 7 or value[0] != "#" or any(c not in "0123456789abcdefABCDEF" for c in value[1:]):
            raise ValueError(f"Invalid {name} color")
        return value.lower()
    logo = str(raw.get("logoData", ""))
    if logo:
        allowed = ("data:image/png;base64,", "data:image/jpeg;base64,", "data:image/webp;base64,")
        if not logo.startswith(allowed):
            raise ValueError("Logo must be PNG, JPEG, or WebP")
        try:
            decoded = base64.b64decode(logo.split(",", 1)[1], validate=True)
        except Exception as error:
            raise ValueError("Invalid logo data") from error
        if len(decoded) > 1024 * 1024:
            raise ValueError("Logo must be 1 MB or smaller")
    return {"eventTitle": str(raw.get("eventTitle", ""))[:80].strip() or DEFAULT_BRANDING["eventTitle"], "subtitle": str(raw.get("subtitle", ""))[:160].strip(), "theme": str(raw.get("theme", "custom"))[:20], "background": color("background", DEFAULT_BRANDING["background"]), "panel": color("panel", DEFAULT_BRANDING["panel"]), "accent": color("accent", DEFAULT_BRANDING["accent"]), "text": color("text", DEFAULT_BRANDING["text"]), "logoData": logo}


def save_branding(raw):
    settings = clean_branding(raw); stamp = now_iso()
    with db() as connection:
        connection.execute("INSERT INTO app_settings(setting_key,setting_value,updated_at) VALUES ('branding',?,?) ON CONFLICT(setting_key) DO UPDATE SET setting_value=excluded.setting_value,updated_at=excluded.updated_at", (json.dumps(settings, separators=(",", ":")), stamp))
    broadcast({"type": "branding_update", "branding": settings, "updatedAt": stamp})
    return settings


def clean_assignment(raw, default_source="external"):
    if not isinstance(raw, dict):
        raise ValueError("Invalid match assignment")

    def first_value(*keys, default=None):
        for key in keys:
            if key in raw and raw[key] is not None:
                return raw[key]
        return default

    table = int(first_value("table", "tableNumber", "table_number", default=0))
    if table < 1 or table > 30:
        raise ValueError("Table must be between 1 and 30")
    player1 = str(first_value("player1", "p1", "redPlayer", "home", "playerOne", "playerA", default="")).strip()[:80]
    player2 = str(first_value("player2", "p2", "bluePlayer", "away", "playerTwo", "playerB", default="")).strip()[:80]
    if not player1 or not player2:
        raise ValueError(f"Table {table} requires both player names")
    best_raw = first_value("bestOf", "best_of", "match", "matchType", default=7)
    if isinstance(best_raw, str) and not best_raw.strip().isdigit():
        digits = "".join(character for character in best_raw if character.isdigit())
        best_raw = digits or 7
    best_of = int(best_raw)
    if best_of < 1 or best_of > 15 or best_of % 2 == 0:
        raise ValueError("Best-of must be an odd number between 1 and 15")
    return {
        "table": table,
        "player1": player1,
        "player2": player2,
        "matchId": str(first_value("matchId", "match_id", "id", default="")).strip()[:80],
        "bestOf": best_of,
        "source": str(first_value("source", default=default_source)).strip()[:40] or default_source,
        "referee": str(first_value("referee", "ref", default="")).strip()[:80],
        "openUrl": str(first_value("openUrl", "open_url", "scoreboardUrl", "url", default="")).strip()[:2000],
    }


def save_assignments(raw_assignments, default_source="external"):
    if isinstance(raw_assignments, dict):
        raw_assignments = raw_assignments.get("matches", raw_assignments.get("assignments", [raw_assignments]))
    if not isinstance(raw_assignments, list) or not raw_assignments:
        raise ValueError("At least one match assignment is required")
    if len(raw_assignments) > 30:
        raise ValueError("No more than 30 match assignments can be sent at once")
    cleaned = [clean_assignment(item, default_source) for item in raw_assignments]
    tables = [item["table"] for item in cleaned]
    if len(set(tables)) != len(tables):
        raise ValueError("Each table may appear only once per request")
    stamp = now_iso()
    saved = []
    with db() as connection:
        for item in cleaned:
            prior = connection.execute(
                "SELECT revision FROM match_assignments WHERE table_number = ?", (item["table"],)
            ).fetchone()
            revision = (int(prior["revision"]) + 1) if prior else 1
            connection.execute("""
                INSERT INTO match_assignments(table_number,player1,player2,match_id,best_of,source,referee,open_url,revision,assigned_at)
                VALUES (?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(table_number) DO UPDATE SET
                    player1=excluded.player1,player2=excluded.player2,match_id=excluded.match_id,
                    best_of=excluded.best_of,source=excluded.source,referee=excluded.referee,
                    open_url=excluded.open_url,revision=excluded.revision,
                    assigned_at=excluded.assigned_at
            """, (item["table"], item["player1"], item["player2"], item["matchId"],
                  item["bestOf"], item["source"], item["referee"], item["openUrl"], revision, stamp))
            for name in (item["player1"], item["player2"]):
                connection.execute("""
                    INSERT INTO player_names(name,last_used_at) VALUES (?,?)
                    ON CONFLICT(name) DO UPDATE SET last_used_at=excluded.last_used_at
                """, (name, stamp))
            saved.append({**item, "revision": revision, "assignedAt": stamp})
            connection.execute("""
                INSERT INTO assignment_delivery(table_number,revision,status,detail,attempted_at)
                VALUES (?,?,'queued','',?)
                ON CONFLICT(table_number) DO UPDATE SET revision=excluded.revision,
                    status=excluded.status,detail=excluded.detail,attempted_at=excluded.attempted_at
            """, (item["table"], revision, stamp))
    broadcast({"type": "match_assignments", "matches": saved, "updatedAt": stamp})
    return saved


def assignment_snapshot(table=None):
    query = """SELECT a.table_number,a.player1,a.player2,a.match_id,a.best_of,a.source,a.referee,a.open_url,
                      a.revision,a.assigned_at,r.device_id,r.received_at,r.revision AS received_revision,
                      x.revision AS delivery_revision,x.status AS delivery_status,
                      x.detail AS delivery_detail,x.attempted_at
               FROM match_assignments a
               LEFT JOIN assignment_receipts r ON r.table_number=a.table_number
               LEFT JOIN assignment_delivery x ON x.table_number=a.table_number"""
    params = ()
    if table is not None:
        query += " WHERE a.table_number = ?"
        params = (int(table),)
    query += " ORDER BY a.table_number"
    with db() as connection:
        rows = connection.execute(query, params).fetchall()
    return [{"table": row["table_number"], "player1": row["player1"], "player2": row["player2"],
             "matchId": row["match_id"], "bestOf": row["best_of"], "source": row["source"],
             "referee": row["referee"], "openUrl": row["open_url"],
             "revision": row["revision"], "assignedAt": row["assigned_at"],
             "received": row["received_revision"] == row["revision"],
             "receivedBy": row["device_id"] if row["received_revision"] == row["revision"] else "",
             "receivedAt": row["received_at"] if row["received_revision"] == row["revision"] else None,
             "deliveryStatus": row["delivery_status"] if row["delivery_revision"] == row["revision"] else "queued",
             "deliveryDetail": row["delivery_detail"] if row["delivery_revision"] == row["revision"] else "",
             "deliveryAttemptedAt": row["attempted_at"] if row["delivery_revision"] == row["revision"] else None}
            for row in rows]


def remembered_names(limit=500):
    with db() as connection:
        rows = connection.execute(
            "SELECT name,last_used_at FROM player_names ORDER BY last_used_at DESC,name COLLATE NOCASE LIMIT ?",
            (max(1, min(int(limit), 2000)),),
        ).fetchall()
    return [{"name": row["name"], "lastUsedAt": row["last_used_at"]} for row in rows]


def manage_remembered_name(raw):
    if not isinstance(raw, dict):
        raise ValueError("Invalid player-name request")
    action = str(raw.get("action", "")).strip().lower()
    stamp = now_iso()
    if action == "clear":
        with db() as connection:
            changed = connection.execute("DELETE FROM player_names").rowcount
    elif action == "delete":
        name = str(raw.get("name", "")).strip()
        if not name:
            raise ValueError("Player name is required")
        with db() as connection:
            changed = connection.execute("DELETE FROM player_names WHERE name = ? COLLATE NOCASE", (name,)).rowcount
        if not changed:
            raise ValueError("Saved player name was not found")
    elif action == "rename":
        old_name = str(raw.get("oldName", "")).strip()
        new_name = str(raw.get("newName", "")).strip()[:80]
        if not old_name or not new_name:
            raise ValueError("Both the existing and new player names are required")
        with db() as connection:
            existing = connection.execute(
                "SELECT name FROM player_names WHERE name = ? COLLATE NOCASE", (old_name,)
            ).fetchone()
            if not existing:
                raise ValueError("Saved player name was not found")
            target = connection.execute(
                "SELECT name FROM player_names WHERE name = ? COLLATE NOCASE", (new_name,)
            ).fetchone()
            if target and target["name"].casefold() != existing["name"].casefold():
                connection.execute("DELETE FROM player_names WHERE name = ? COLLATE NOCASE", (old_name,))
                connection.execute(
                    "UPDATE player_names SET name = ?, last_used_at = ? WHERE name = ? COLLATE NOCASE",
                    (new_name, stamp, target["name"]),
                )
            else:
                connection.execute(
                    "UPDATE player_names SET name = ?, last_used_at = ? WHERE name = ? COLLATE NOCASE",
                    (new_name, stamp, old_name),
                )
            changed = 1
    else:
        raise ValueError("Action must be rename, delete, or clear")
    names = remembered_names()
    broadcast({"type": "player_names_update", "playerNames": names, "updatedAt": stamp})
    return {"action": action, "changed": changed, "playerNames": names}


def remember_table_device(table, device_id, ip_address):
    try:
        address = ipaddress.ip_address(str(ip_address))
        if not (address.is_private or address.is_link_local or address.is_loopback):
            return
    except ValueError:
        return
    with db() as connection:
        connection.execute("""
            INSERT INTO table_devices(table_number,device_id,ip_address,updated_at) VALUES (?,?,?,?)
            ON CONFLICT(table_number) DO UPDATE SET device_id=excluded.device_id,
                ip_address=excluded.ip_address,updated_at=excluded.updated_at
        """, (int(table), str(device_id)[:40], str(address), now_iso()))


def save_delivery_status(table, revision, status, detail=""):
    stamp = now_iso()
    try:
        with db() as connection:
            connection.execute("""
                INSERT INTO assignment_delivery(table_number,revision,status,detail,attempted_at)
                VALUES (?,?,?,?,?)
                ON CONFLICT(table_number) DO UPDATE SET revision=excluded.revision,
                    status=excluded.status,detail=excluded.detail,attempted_at=excluded.attempted_at
            """, (int(table), int(revision), str(status)[:30], str(detail)[:200], stamp))
    except sqlite3.Error:
        return
    broadcast({"type": "match_assignment_delivery", "table": int(table), "revision": int(revision),
               "status": str(status)[:30], "detail": str(detail)[:200], "attemptedAt": stamp})


def delete_assignment(table):
    table = int(table)
    if table < 1 or table > 30:
        raise ValueError("Table must be between 1 and 30")
    with db() as connection:
        removed = connection.execute("DELETE FROM match_assignments WHERE table_number = ?", (table,)).rowcount
        connection.execute("DELETE FROM assignment_receipts WHERE table_number = ?", (table,))
        connection.execute("DELETE FROM assignment_delivery WHERE table_number = ?", (table,))
    stamp = now_iso()
    if removed:
        broadcast({"type": "match_assignment_removed", "table": table, "updatedAt": stamp})
    return bool(removed)


def acknowledge_assignment(raw):
    if not isinstance(raw, dict):
        raise ValueError("Invalid assignment receipt")
    table = int(raw.get("table", raw.get("tableNumber", 0)))
    revision = int(raw.get("revision", 0))
    device_id = str(raw.get("deviceId", raw.get("device_id", ""))).strip()[:40]
    if table < 1 or table > 30 or revision < 1 or not device_id:
        raise ValueError("Receipt requires table, revision, and deviceId")
    current = assignment_snapshot(table)
    if not current or current[0]["revision"] != revision:
        raise ValueError("Assignment revision is no longer current")
    stamp = now_iso()
    with db() as connection:
        connection.execute("""
            INSERT INTO assignment_receipts(table_number,revision,device_id,received_at) VALUES (?,?,?,?)
            ON CONFLICT(table_number) DO UPDATE SET revision=excluded.revision,
                device_id=excluded.device_id,received_at=excluded.received_at
        """, (table, revision, device_id, stamp))
    broadcast({"type": "match_assignment_received", "table": table, "revision": revision,
               "deviceId": device_id, "receivedAt": stamp})
    return {"table": table, "revision": revision, "deviceId": device_id, "receivedAt": stamp}


def retrieve_assignment(table, device_id="", ip_address=""):
    """Return the current table assignment and record a CYD pull when identified."""
    matches = assignment_snapshot(table)
    device_id = str(device_id).strip()[:40]
    if matches and device_id:
        if ip_address:
            remember_table_device(table, device_id, ip_address)
        acknowledge_assignment({"table": table, "revision": matches[0]["revision"],
                                "deviceId": device_id})
        save_delivery_status(table, matches[0]["revision"], "received",
                             f"Retrieved by Table {table}")
        matches = assignment_snapshot(table)
    return matches[0] if matches else None


def score_summary(game_scores):
    return " | ".join(f"G{index + 1} {game[0]}-{game[1]}" for index, game in enumerate(game_scores))


def clean_game_scores(raw_scores):
    game_scores = []
    for game in (raw_scores or [])[:15]:
        if isinstance(game, (list, tuple)) and len(game) >= 2:
            game_scores.append([max(0, int(game[0])), max(0, int(game[1]))])
        elif isinstance(game, dict):
            first = game.get("player1", game.get("home"))
            second = game.get("player2", game.get("away"))
            if first is not None and second is not None:
                game_scores.append([max(0, int(first)), max(0, int(second))])
    return game_scores


def clean_payload(raw):
    required = ("table", "deviceId", "player1", "player2", "status")
    if not isinstance(raw, dict) or any(key not in raw for key in required):
        raise ValueError("Missing required device fields")
    table = int(raw["table"])
    if table < 1 or table > 30:
        raise ValueError("Table must be between 1 and 30")
    game_scores = clean_game_scores(raw.get("gameScores", []))
    return {
        "table": table,
        "deviceId": str(raw["deviceId"])[:40],
        "player1": str(raw["player1"])[:80],
        "player2": str(raw["player2"])[:80],
        "score1": max(0, int(raw.get("score1", 0))),
        "score2": max(0, int(raw.get("score2", 0))),
        "games1": max(0, int(raw.get("games1", 0))),
        "games2": max(0, int(raw.get("games2", 0))),
        "gameNumber": max(1, int(raw.get("gameNumber", 1))),
        "bestOf": max(1, int(raw.get("bestOf", 7))),
        "status": str(raw["status"])[:30],
        "gameType": str(raw.get("gameType", "standard_match"))[:40],
        "durationSeconds": max(0, int(raw.get("durationSeconds", 0))),
        "remainingSeconds": max(0, int(raw.get("remainingSeconds", 0))),
        "blitz": bool(raw.get("blitz", False)),
        "suddenDeath": bool(raw.get("suddenDeath", False)),
        "leftPlayer": 1 if int(raw.get("leftPlayer", 0)) == 1 else 0,
        "timeoutLabel": str(raw.get("timeoutLabel", ""))[:40],
        "timeoutUsed1": bool(raw.get("timeoutUsed1", False)),
        "timeoutUsed2": bool(raw.get("timeoutUsed2", False)),
        "gameScores": game_scores,
        "scoreSummary": score_summary(game_scores),
    }


def save_update(payload):
    stamp = now_iso()
    completed_assignment = False
    with db() as connection:
        previous_row = connection.execute(
            "SELECT payload, updated_at FROM table_state WHERE table_number = ?",
            (payload["table"],),
        ).fetchone()
        if payload["gameType"] == "standard_match":
            elapsed = 0
            if previous_row:
                previous = json.loads(previous_row["payload"])
                same_match = (
                    previous.get("gameType", "standard_match") == "standard_match"
                    and "elapsedSeconds" in previous
                    and previous.get("status") not in ("complete", "abandoned")
                    and previous.get("player1") == payload["player1"]
                    and previous.get("player2") == payload["player2"]
                )
                if same_match:
                    elapsed = max(0, int(previous.get("elapsedSeconds", 0)))
                    if previous.get("status") != "timeout":
                        previous_time = datetime.fromisoformat(previous_row["updated_at"])
                        elapsed += max(0, int((datetime.now(timezone.utc) - previous_time).total_seconds()))
            payload["elapsedSeconds"] = elapsed
        encoded = json.dumps(payload, separators=(",", ":"))
        connection.execute("""
            INSERT INTO table_state (
                table_number, device_id, player1, player2, score1, score2,
                games1, games2, game_number, best_of, status, payload, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(table_number) DO UPDATE SET
                device_id=excluded.device_id, player1=excluded.player1,
                player2=excluded.player2, score1=excluded.score1,
                score2=excluded.score2, games1=excluded.games1,
                games2=excluded.games2, game_number=excluded.game_number,
                best_of=excluded.best_of, status=excluded.status,
                payload=excluded.payload, updated_at=excluded.updated_at
        """, (
            payload["table"], payload["deviceId"], payload["player1"],
            payload["player2"], payload["score1"], payload["score2"],
            payload["games1"], payload["games2"], payload["gameNumber"],
            payload["bestOf"], payload["status"], encoded, stamp,
        ))
        connection.execute("""
            INSERT INTO score_events(table_number, device_id, event_type, payload, created_at)
            VALUES (?, ?, ?, ?, ?)
        """, (payload["table"], payload["deviceId"], payload["status"], encoded, stamp))
        if payload["status"] == "complete":
            assignment = connection.execute(
                "SELECT player1,player2 FROM match_assignments WHERE table_number=?", (payload["table"],)
            ).fetchone()
            completed_assignment = bool(
                assignment and assignment["player1"] == payload["player1"]
                and assignment["player2"] == payload["player2"]
            )
            if completed_assignment:
                connection.execute("DELETE FROM match_assignments WHERE table_number=?", (payload["table"],))
                connection.execute("DELETE FROM assignment_receipts WHERE table_number=?", (payload["table"],))
                connection.execute("DELETE FROM assignment_delivery WHERE table_number=?", (payload["table"],))
    broadcast({"type": "table_update", "table": payload, "updatedAt": stamp})
    if completed_assignment:
        broadcast({"type": "match_assignment_removed", "table": payload["table"], "updatedAt": stamp})


def table_snapshot(include_admin=False):
    with db() as connection:
        rows = connection.execute("SELECT payload, updated_at FROM table_state ORDER BY table_number").fetchall()
    snapshots = []
    for row in rows:
        payload = json.loads(row["payload"])
        if not include_admin:
            payload.pop("correction", None)
        snapshots.append({**payload, "updatedAt": row["updated_at"]})
    return snapshots


def recent_events(limit=100):
    with db() as connection:
        rows = connection.execute(
            "SELECT id, table_number, event_type, payload, created_at FROM score_events ORDER BY id DESC LIMIT ?",
            (limit,),
        ).fetchall()
    return [{"id": row["id"], "table": row["table_number"], "type": row["event_type"],
             "payload": json.loads(row["payload"]), "createdAt": row["created_at"]} for row in rows]


def correct_match_event(event_id, raw_scores, reason):
    reason = str(reason or "").strip()
    if not reason:
        raise ValueError("A correction reason is required")
    if len(reason) > 500:
        raise ValueError("Correction reason is too long")
    game_scores = clean_game_scores(raw_scores)
    if not game_scores:
        raise ValueError("At least one game score is required")
    stamp = now_iso()
    with db() as connection:
        row = connection.execute(
            "SELECT id, table_number, device_id, event_type, payload FROM score_events WHERE id = ?",
            (int(event_id),),
        ).fetchone()
        if not row:
            raise ValueError("Match card was not found")
        original = json.loads(row["payload"])
        if row["event_type"] != "complete" and original.get("status") != "complete":
            raise ValueError("Only completed match cards can be corrected")
        corrected = dict(original)
        corrected["gameScores"] = game_scores
        corrected["scoreSummary"] = score_summary(game_scores)
        corrected["games1"] = sum(1 for first, second in game_scores if first > second)
        corrected["games2"] = sum(1 for first, second in game_scores if second > first)
        prior = original.get("correction") if isinstance(original.get("correction"), dict) else {}
        corrected["correction"] = {
            "corrected": True,
            "count": max(0, int(prior.get("count", 0))) + 1,
            "reason": reason,
            "correctedAt": stamp,
        }
        encoded = json.dumps(corrected, separators=(",", ":"))
        connection.execute(
            "INSERT INTO match_corrections(event_id, original_payload, corrected_payload, reason, corrected_at) VALUES (?, ?, ?, ?, ?)",
            (row["id"], row["payload"], encoded, reason, stamp),
        )
        connection.execute("UPDATE score_events SET payload = ? WHERE id = ?", (encoded, row["id"]))
        current = connection.execute(
            "SELECT payload FROM table_state WHERE table_number = ?", (row["table_number"],)
        ).fetchone()
        if current:
            current_payload = json.loads(current["payload"])
            same_card = (
                current_payload.get("status") == "complete"
                and current_payload.get("deviceId") == corrected.get("deviceId")
                and current_payload.get("player1") == corrected.get("player1")
                and current_payload.get("player2") == corrected.get("player2")
            )
            if same_card:
                connection.execute(
                    "UPDATE table_state SET games1 = ?, games2 = ?, payload = ?, updated_at = ? WHERE table_number = ?",
                    (corrected["games1"], corrected["games2"], encoded, stamp, row["table_number"]),
                )
    public_payload = dict(corrected)
    public_payload.pop("correction", None)
    broadcast({"type": "match_correction", "table": public_payload, "updatedAt": stamp, "eventId": int(event_id)})
    return corrected


def create_admin_session():
    token = secrets.token_urlsafe(32)
    with admin_session_lock:
        admin_sessions[token] = time.time() + ADMIN_SESSION_SECONDS
    return token


def admin_session_valid(token):
    if not token:
        return False
    now = time.time()
    with admin_session_lock:
        expired = [key for key, expires in admin_sessions.items() if expires <= now]
        for key in expired:
            del admin_sessions[key]
        expires = admin_sessions.get(token)
        if not expires:
            return False
        admin_sessions[token] = now + ADMIN_SESSION_SECONDS
    return True


def end_admin_session(token):
    if not token:
        return
    with admin_session_lock:
        admin_sessions.pop(token, None)


def broadcast(message):
    with subscriber_lock:
        dead = []
        for subscriber in subscribers:
            try:
                subscriber.put_nowait(message)
            except queue.Full:
                dead.append(subscriber)
        for subscriber in dead:
            subscribers.remove(subscriber)


def serve_discovery():
    response = json.dumps({"service": "scorekeeper-hub", "port": PORT, "version": APP_VERSION}).encode()
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as discovery:
        discovery.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        discovery.bind(("0.0.0.0", DISCOVERY_PORT))
        while True:
            try:
                message, address = discovery.recvfrom(256)
                if message.strip() == b"SCOREKEEPER_HUB_DISCOVER":
                    discovery.sendto(response, address)
            except OSError as error:
                print(f"Discovery service error: {error}")
                time.sleep(1)


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(STATIC), **kwargs)

    def log_message(self, format, *args):
        print(f"[{self.log_date_time_string()}] {format % args}")

    def end_headers(self):
        path = posixpath.normpath(unquote(urlparse(self.path).path))
        if path.endswith(".html") or path == "/":
            self.send_header("Cache-Control", "no-store, no-cache, must-revalidate")
            self.send_header("Pragma", "no-cache")
            self.send_header("Expires", "0")
        super().end_headers()

    def redirect_response(self, location):
        self.send_response(HTTPStatus.SEE_OTHER)
        self.send_header("Location", location)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def json_response(self, data, status=HTTPStatus.OK, headers=None):
        body = json.dumps(data).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for name, value in (headers or {}).items():
            self.send_header(name, value)
        self.end_headers()
        self.wfile.write(body)

    def admin_token(self):
        try:
            cookie = SimpleCookie(self.headers.get("Cookie", ""))
            item = cookie.get(ADMIN_COOKIE)
            return item.value if item else None
        except Exception:
            return None

    def is_admin(self):
        return admin_session_valid(self.admin_token())

    def require_admin(self):
        if self.is_admin():
            return True
        self.json_response({"ok": False, "error": "Admin login required"}, HTTPStatus.UNAUTHORIZED)
        return False

    def do_GET(self):
        parsed = urlparse(self.path)
        path = posixpath.normpath(unquote(parsed.path))
        if path in ("/admin.html", "/matches.html"):
            if not self.is_admin():
                return self.redirect_response("/admin-login.html")
            self.path = path
            return super().do_GET()
        if path == "/admin-login.html":
            if self.is_admin():
                return self.redirect_response("/admin.html")
            self.path = "/admin-login.html"
            return super().do_GET()
        if path == "/api/admin/dashboard":
            if not self.require_admin():
                return
            try:
                limit = int(parse_qs(parsed.query).get("limit", ["5000"])[0])
            except ValueError:
                limit = 5000
            limit = max(1, min(limit, 5000))
            return self.json_response({"ok": True, "tables": table_snapshot(include_admin=True),
                                       "events": recent_events(limit), "assignments": assignment_snapshot(),
                                       "playerNames": remembered_names(), "serverTime": now_iso(),
                                       "version": APP_VERSION})
        if path == "/api/matches":
            return self.json_response({"ok": True, "matches": assignment_snapshot(),
                                       "serverTime": now_iso(), "version": APP_VERSION})
        if path in ("/api/match", "/api/assignment"):
            try:
                table = int(parse_qs(parsed.query).get("table", ["0"])[0])
                if table < 1 or table > 30:
                    raise ValueError
            except ValueError:
                return self.json_response({"ok": False, "error": "Table must be between 1 and 30"},
                                          HTTPStatus.BAD_REQUEST)
            matches = assignment_snapshot(table)
            return self.json_response({"ok": True, "match": matches[0] if matches else None,
                                       "serverTime": now_iso(), "version": APP_VERSION})
        if path.startswith("/api/matches/table/"):
            try:
                table = int(path.rsplit("/", 1)[1])
                if table < 1 or table > 30:
                    raise ValueError
            except ValueError:
                return self.json_response({"ok": False, "error": "Table must be between 1 and 30"},
                                          HTTPStatus.BAD_REQUEST)
            device_id = str(parse_qs(parsed.query).get("deviceId", [""])[0]).strip()[:40]
            match = retrieve_assignment(table, device_id, self.client_address[0])
            return self.json_response({"ok": True, "match": match,
                                       "serverTime": now_iso(), "version": APP_VERSION})
        if path == "/api/tables":
            return self.json_response({"ok": True, "tables": table_snapshot(),
                                       "serverTime": now_iso(), "version": APP_VERSION})
        if path == "/api/events":
            if not self.require_admin():
                return
            return self.json_response({"ok": True, "events": recent_events()})
        if path == "/api/health":
            return self.json_response({"ok": True, "service": "scorekeeper-hub",
                                       "version": APP_VERSION, "time": now_iso()})
        if path == "/api/branding":
            return self.json_response({"ok": True, "branding": branding_settings()})
        if path == "/api/stream":
            return self.stream_events()
        if path == "/":
            self.path = "/index.html"
        return super().do_GET()

    def do_POST(self):
        path = posixpath.normpath(unquote(urlparse(self.path).path))
        if path == "/api/admin/login":
            return self.admin_login()
        if path == "/api/admin/logout":
            token = self.admin_token()
            end_admin_session(token)
            return self.json_response({"ok": True}, headers={
                "Set-Cookie": f"{ADMIN_COOKIE}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0"
            })
        if path == "/api/admin/correct-match":
            if not self.require_admin():
                return
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if length < 2 or length > 16384:
                    raise ValueError("Invalid correction request size")
                raw = json.loads(self.rfile.read(length))
                if not isinstance(raw, dict):
                    raise ValueError("Invalid correction request")
                corrected = correct_match_event(raw.get("eventId"), raw.get("gameScores"), raw.get("reason"))
                return self.json_response({"ok": True, "matchCard": corrected, "correctedAt": now_iso()})
            except (ValueError, TypeError, json.JSONDecodeError) as error:
                return self.json_response({"ok": False, "error": str(error)}, HTTPStatus.BAD_REQUEST)
        if path == "/api/admin/branding":
            if not self.require_admin():
                return
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if length < 2 or length > 1500000:
                    raise ValueError("Invalid branding request size")
                settings = save_branding(json.loads(self.rfile.read(length)))
                return self.json_response({"ok": True, "branding": settings})
            except (ValueError, TypeError, json.JSONDecodeError) as error:
                return self.json_response({"ok": False, "error": str(error)}, HTTPStatus.BAD_REQUEST)
        if path == "/api/matches/ack":
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if length < 2 or length > 2048:
                    raise ValueError("Invalid assignment receipt size")
                receipt = acknowledge_assignment(json.loads(self.rfile.read(length)))
                return self.json_response({"ok": True, "receipt": receipt})
            except (ValueError, TypeError, json.JSONDecodeError) as error:
                return self.json_response({"ok": False, "error": str(error)}, HTTPStatus.BAD_REQUEST)
        if path == "/api/admin/player-names":
            if not self.require_admin():
                return
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if length < 2 or length > 4096:
                    raise ValueError("Invalid player-name request size")
                result = manage_remembered_name(json.loads(self.rfile.read(length)))
                return self.json_response({"ok": True, **result})
            except (ValueError, TypeError, json.JSONDecodeError) as error:
                return self.json_response({"ok": False, "error": str(error)}, HTTPStatus.BAD_REQUEST)
        if path in ("/api/admin/matches", "/api/matches"):
            if path == "/api/admin/matches" and not self.require_admin():
                return
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if length < 2 or length > 65536:
                    raise ValueError("Invalid match assignment request size")
                raw = json.loads(self.rfile.read(length))
                saved = save_assignments(raw, "manual" if path == "/api/admin/matches" else "td-app")
                return self.json_response({"ok": True, "matches": saved, "assignedAt": now_iso()})
            except (ValueError, TypeError, json.JSONDecodeError) as error:
                return self.json_response({"ok": False, "error": str(error)}, HTTPStatus.BAD_REQUEST)
        if path != "/api/update":
            return self.json_response({"ok": False, "error": "Not found"}, HTTPStatus.NOT_FOUND)
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length < 2 or length > 16384:
                raise ValueError("Invalid payload size")
            payload = clean_payload(json.loads(self.rfile.read(length)))
            remember_table_device(payload["table"], payload["deviceId"], self.client_address[0])
            save_update(payload)
            self.json_response({"ok": True, "receivedAt": now_iso()})
        except (ValueError, TypeError, json.JSONDecodeError) as error:
            self.json_response({"ok": False, "error": str(error)}, HTTPStatus.BAD_REQUEST)

    def do_DELETE(self):
        path = posixpath.normpath(unquote(urlparse(self.path).path))
        if not path.startswith("/api/admin/matches/"):
            return self.json_response({"ok": False, "error": "Not found"}, HTTPStatus.NOT_FOUND)
        if not self.require_admin():
            return
        try:
            table = int(path.rsplit("/", 1)[1])
            removed = delete_assignment(table)
            return self.json_response({"ok": True, "removed": removed, "table": table})
        except (ValueError, TypeError):
            return self.json_response({"ok": False, "error": "Table must be between 1 and 30"},
                                      HTTPStatus.BAD_REQUEST)

    def admin_login(self):
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length < 2 or length > 1024:
                raise ValueError("Invalid login request")
            raw = json.loads(self.rfile.read(length))
            if not isinstance(raw, dict):
                raise ValueError("Invalid login request")
            supplied = str(raw.get("password", ""))
            if not hmac.compare_digest(supplied, ADMIN_PASSWORD):
                time.sleep(0.25)
                return self.json_response({"ok": False, "error": "Incorrect password"},
                                          HTTPStatus.UNAUTHORIZED)
            token = create_admin_session()
            self.json_response({"ok": True}, headers={
                "Set-Cookie": f"{ADMIN_COOKIE}={token}; Path=/; HttpOnly; SameSite=Strict; Max-Age={ADMIN_SESSION_SECONDS}"
            })
        except (ValueError, TypeError, json.JSONDecodeError) as error:
            self.json_response({"ok": False, "error": str(error)}, HTTPStatus.BAD_REQUEST)

    def stream_events(self):
        channel = queue.Queue(maxsize=20)
        with subscriber_lock:
            subscribers.append(channel)
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "keep-alive")
        self.end_headers()
        try:
            self.wfile.write(b"event: connected\ndata: {}\n\n")
            self.wfile.flush()
            while True:
                try:
                    message = channel.get(timeout=15)
                    data = json.dumps(message).encode()
                    self.wfile.write(b"event: update\ndata: " + data + b"\n\n")
                except queue.Empty:
                    self.wfile.write(b": keepalive\n\n")
                self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError):
            pass
        finally:
            with subscriber_lock:
                if channel in subscribers:
                    subscribers.remove(channel)


if __name__ == "__main__":
    initialize()
    threading.Thread(target=serve_discovery, daemon=True).start()
    server = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    print(f"Scorekeeper Hub: http://0.0.0.0:{PORT} (discovery UDP {DISCOVERY_PORT})")
    server.serve_forever()
