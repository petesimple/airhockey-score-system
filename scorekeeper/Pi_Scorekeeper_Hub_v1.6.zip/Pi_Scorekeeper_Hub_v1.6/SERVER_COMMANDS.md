# Server commands for the github Pi

Connect from the Mac:

```bash
ssh project@github.local
```

Use the current LAN IP if `github.local` is unavailable.

Start the scorekeeper server:

```bash
sudo systemctl start scorekeeper-hub
```

Stop it:

```bash
sudo systemctl stop scorekeeper-hub
```

Restart it after code changes:

```bash
sudo systemctl restart scorekeeper-hub
```

Check status:

```bash
sudo systemctl status scorekeeper-hub --no-pager
```

Check the running version:

```bash
curl -fsS http://127.0.0.1:8081/api/health
```

Watch live server logs:

```bash
sudo journalctl -u scorekeeper-hub -f
```

After restarting, reload the browser with Command Shift R to bypass its cache.
