# Changelog

## v1.6

- Replaced the obsolete fixed-IP Android-tablet handoff with table-based CYD polling.
- Added automatic Pi hub discovery on UDP port 8082 so CYDs work on different private LAN ranges without configured IP routes.
- CYDs identify themselves and retrieve the assignment for their saved table number; the dispatch board shows when the table received it.
- Completed CYD match reports automatically clear the matching table assignment.
- Kept the existing TD match fields and the CYD's original Google/TD match-feed fallback compatible.
- Moved the SQLite database to persistent per-user storage during installation so scores and remembered names survive version-folder upgrades.

## v1.5

- Added a searchable remembered-name manager to Match Dispatch.
- Saved autocomplete names can be renamed, deleted individually, or cleared in bulk.
- Name cleanup never alters score events, completed match cards, or correction history.

## v1.4

- Simplified Match Dispatch to the same table-first workflow as TD: choose a table and send, with no CYD IP field on match rows.
- Added the former fixed-IP Android-tablet routing experiment. This was removed in v1.6 because it was not the CYD delivery mechanism.

## v1.3

- Added an independent 30-table Match Dispatch board with editable assignments and remembered player names.
- Added vendor-neutral match assignment APIs for the TD app and other chart systems.
- Added per-table CYD polling, assignment revisions, real-time updates, and optional delivery receipts.
- Match assignments persist in SQLite and do not change the existing CYD score-update protocol.
- Fixed upgrades so `install.sh` restarts an already-running older service after replacing its unit file.

## v1.2

- Added admin-controlled live-page themes, custom colors, event titles, subtitles, and event logos.
- Branding changes persist in SQLite and update connected live pages immediately.
- Added Streamlabs-friendly `table` and `view` URL controls with `normal`, `mirror`, and `180` modes.

## v1.1

- Added expandable match cards with per-game scores to TD Admin.
- Added quick score summaries to stored reports and activity rows.
- Added corrections with required reasons and retained audit history.
- Corrections recalculate match totals and update the current table snapshot when applicable.

## v1.0

Initial versioned release of the complete 7-6 Scorekeeper Pi Hub.

1. Red and blue game-win pips remain attached to player identity through CYD
   side swaps, Pi mirror view, and 180 degree rotation.
2. Completed matches display a match card result even when individual game
   scores were not reported by an older CYD.
3. Pi viewer controls, jumbotron pages, admin authentication, event history,
   standard matches, and Photon Blitz behavior remain available.
4. TD Admin displays the release version in its footer.
5. API health and table responses report the release version.
6. A local SVG logo and server command guide are included.
