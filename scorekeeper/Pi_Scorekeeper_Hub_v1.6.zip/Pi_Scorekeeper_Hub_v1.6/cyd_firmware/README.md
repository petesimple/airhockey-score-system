# CYD firmware for Pi Hub v1.6

Flash `CYD_Scorekeeper_v1_6.ino` with `scorekeeper_logo.h` in the same Arduino sketch folder. This is a copy of the current CYD scorekeeper with Pi hub discovery and table-based assignment polling added.

The existing behavior remains available:

- The CYD keeps its saved Wi-Fi networks and saved table number.
- The original Google/TD called-match feed remains the fallback when the Pi has no assignment.
- Score updates still post to the Pi's `/api/update` endpoint.

New behavior:

- On any connected LAN, the CYD broadcasts `SCOREKEEPER_HUB_DISCOVER` on UDP port 8082.
- The Pi replies with its current address; no table or CYD IP list is required.
- The CYD polls `/api/matches/table/TABLE_NUMBER?deviceId=MAC_ADDRESS` every three seconds while waiting for a match.
- A new assignment automatically opens the called-match list and the Pi marks that table as having received it.

Use **Table** on the CYD to set the correct table number. The manual Hub IP screen remains available as a troubleshooting override, but normal operation does not require it.
