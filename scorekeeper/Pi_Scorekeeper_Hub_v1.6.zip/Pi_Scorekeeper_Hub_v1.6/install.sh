#!/usr/bin/env bash
set -euo pipefail
hub_dir="$(cd "$(dirname "$0")" && pwd)"
service_file="/etc/systemd/system/scorekeeper-hub.service"
app_version="$(tr -d '\r\n' < "$hub_dir/VERSION")"
account_dir="$(getent passwd "$USER" | cut -d: -f6)"
data_dir="$account_dir/.local/share/scorekeeper-hub"
database_file="$data_dir/scorekeeper.db"
old_hub_dir="$(systemctl show -p WorkingDirectory --value scorekeeper-hub 2>/dev/null || true)"

mkdir -p "$data_dir"
if [[ ! -f "$database_file" && -n "$old_hub_dir" && -f "$old_hub_dir/scorekeeper.db" ]]; then
  cp "$old_hub_dir/scorekeeper.db" "$database_file"
  echo "Preserved existing scores, assignments, and saved names in $database_file"
fi

sudo tee "$service_file" >/dev/null <<EOF
[Unit]
Description=7-6 Scorekeeper Table Hub $app_version
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$hub_dir
ExecStart=/usr/bin/python3 $hub_dir/server.py
Environment=SCOREKEEPER_DB=$database_file
Restart=on-failure
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable scorekeeper-hub
sudo systemctl restart scorekeeper-hub
echo "Scorekeeper Hub $app_version installed. Open http://$(hostname -I | awk '{print $1}'):8081"
