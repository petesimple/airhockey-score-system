# 7-6 Scorekeeper Pi Hub

Local real-time dashboard and event store for the CYD table scorekeepers.

**Version:** v1.6

## Independent match dispatch

Open `http://PI_IP_ADDRESS:8081/matches.html` (using the same TD Admin login) to build and send an editable list for Tables 1 through 30. Choose the table, enter the players, and press Send; CYD addressing stays behind the scenes. The board remembers unsent browser edits, persists sent assignments and previously used player names on the Pi, accepts pasted CSV/tab-separated lists, and reports whether the table handoff opened or failed.

Use **Manage saved names** on the Match Dispatch page to search the autocomplete list, correct a spelling, remove one name, or clear the list before a new tournament. These operations affect only remembered autocomplete suggestions; stored score history and completed match cards remain unchanged.

The Pi owns this queue, so the feature works without the TD app. The TD app or any other chart system can use the same vendor-neutral HTTP API on the tournament LAN. There are no fixed table IPs: each CYD keeps its own table number, automatically discovers the Pi, and polls the assignment for that table. The Pi records the pull so Match Dispatch can show **Received by table**.

This does not alter the working TD hub. Its current match fields remain accepted by the Pi API, and the updated CYD retains its original Google/TD feed as a fallback when the Pi has no assignment.

Send one match:

```bash
curl -X POST http://PI_IP_ADDRESS:8081/api/matches \
  -H 'Content-Type: application/json' \
  -d '{"table":1,"player1":"Alice","player2":"Bob","matchId":"R1-M01","bestOf":7,"source":"my-chart"}'
```

Send up to 30 matches in one request:

```bash
curl -X POST http://PI_IP_ADDRESS:8081/api/matches \
  -H 'Content-Type: application/json' \
  -d '{"matches":[{"table":1,"player1":"Alice","player2":"Bob"},{"table":2,"player1":"Carlos","player2":"Dana"}]}'
```

A CYD assigned to Table 1 polls `GET /api/matches/table/1?deviceId=DEVICE_ID`. For simple firmware adapters, `GET /api/match?table=1` and `GET /api/assignment?table=1` return the same assignment without recording receipt. A CYD remembers the returned `revision` and loads a match only when that revision changes. A separate receipt call remains available:

```bash
curl -X POST http://PI_IP_ADDRESS:8081/api/matches/ack \
  -H 'Content-Type: application/json' \
  -d '{"table":1,"revision":3,"deviceId":"cyd-01"}'
```

Input aliases make adapters easier: the current TD fields `p1`, `p2`, `matchType`, `scoreboardUrl`, and `referee` are accepted, along with `tableNumber`, `redPlayer`/`bluePlayer`, `home`/`away`, `match_id`, and `best_of`. New integrations should prefer the canonical fields shown above. Assignment APIs are intentionally open on the local tournament network, like `/api/update`; do not expose this unencrypted service directly to the internet.

Updated CYD firmware discovers the hub by broadcasting `SCOREKEEPER_HUB_DISCOVER` on UDP port `8082`. The Pi replies with its current address and HTTP port. This works on `10.x`, `192.168.x`, and other private tournament LANs without hard-coded device addresses. The CYD's table number is the routing key.

## Update each CYD once

The Pi cannot add polling behavior to an already-flashed CYD by itself. Open `cyd_firmware/CYD_Scorekeeper_v1_6.ino` in Arduino IDE with `cyd_firmware/scorekeeper_logo.h` beside it, then flash each scorekeeper once. Existing Wi-Fi, manual scoring, TD/Google fallback, match history, and score reporting behavior are retained. After flashing, set the scorekeeper's own table number; no CYD IP entry is needed on the Pi.

TD Admin includes **Live page customization** for theme presets, custom colors, event text, and an optional PNG/JPEG/WebP logo up to 1 MB. Saved branding is applied to the public live page and pushed to connected displays immediately.

## Admin match-card corrections

Completed device reports appear under **Completed match cards** in TD Admin. Expand a card to see every game score and use **Correct match card** to fix an incorrect report. A reason is required for each correction. The hub retains the prior payload and correction history in SQLite, recalculates the match game count, and marks the card as corrected.

This complete build is intended for the Raspberry Pi test machine named
`github`. The hostname can normally be reached as `github.local`; use the Pi's
LAN IP instead if local hostname discovery is unavailable.

## Copy the complete folder to the github Pi

After downloading and extracting `Pi_Scorekeeper_Hub_v1.6.zip` on the Mac:

```bash
scp -r ~/Downloads/Pi_Scorekeeper_Hub_v1.6 project@github.local:~/Desktop/
ssh project@github.local
```

If `github.local` does not resolve, replace it with the Pi's current LAN IP.

On the Pi:

```bash
cd ~/Desktop/Pi_Scorekeeper_Hub_v1.6
chmod +x install.sh
./install.sh
```

Running `install.sh` updates the `scorekeeper-hub` systemd service to use this
exact folder and starts it automatically at boot.

## Stop, start, and immediately reload changes

```bash
sudo systemctl stop scorekeeper-hub
sudo systemctl start scorekeeper-hub
sudo systemctl restart scorekeeper-hub
sudo systemctl status scorekeeper-hub --no-pager
```

After changing HTML, CSS, JavaScript, or Python, use:

```bash
sudo systemctl restart scorekeeper-hub
curl -fsS http://127.0.0.1:8081/api/health
```

Then reload the browser with Command Shift R. The health response should report
`"version": "v1.6"`.

## Test on the Pi

1. Copy this entire folder to the Pi.
2. In a terminal, enter the folder and run `python3 server.py`.
3. Open `http://PI_IP_ADDRESS:8081` on a booth computer or tablet.
4. Test the API with:

```bash
curl -X POST http://PI_IP_ADDRESS:8081/api/update \
  -H 'Content-Type: application/json' \
  -d '{"table":1,"deviceId":"test-1","player1":"Alice","player2":"Bob","score1":4,"score2":3,"games1":1,"games2":0,"gameNumber":2,"bestOf":7,"status":"playing"}'
```

Refresh is not required; the dashboard updates through a live server-event stream.

## Player game-win pips

Games won are shown as colored circular pips beneath each player's current
score. Player 1's pips are red and Player 2's pips are blue. The color, score,
timeout state, and game-win count are assembled into one player state before
physical side swaps or Pi viewer transforms are applied. As a result, the pips
move with the correct player during CYD side swaps, Pi Mirror view, and 180°
rotation. Completed scorecards also show the same player-owned pips.

Every state reported as `complete` opens the match card result, even when an
older CYD did not include the optional `gameScores` array. The winner, final
match score, and game-win pips still appear, along with a note that the
individual game scores were not reported.

This is a Pi display-only change. The existing `games1` and `games2` fields in
the CYD update protocol are unchanged.

## Pi display view controls

### Streamlabs URL view control

Use a standard `view` query parameter to lock a table feed to a camera orientation:

```text
http://PI_IP:8081/?table=1&view=normal
http://PI_IP:8081/?table=1&view=mirror
http://PI_IP:8081/?table=1&view=180
```

The shorthand forms `?table=1:mirror` and `?table=1:180` are also accepted. A URL view overrides that browser's saved preference. Clicking a view button on a single-table page updates the URL, allowing the resulting address to be copied into Streamlabs.

Each table card has its own **Normal**, **Mirror**, and **180°** buttons. Mirror
swaps the left and right player sides while keeping all text upright and
readable; 180° rotates the score view. These buttons affect only the score view
rendered by this web browser. The choice
for each table is saved locally in the Pi browser, so refreshing the page keeps
the selected view. Choosing **Normal** resets that table.

View choices are never sent to `/api/update`, stored in `scorekeeper.db`, or
broadcast to a CYD referee device.

The scorekeeper logo is bundled locally in `static/logo.svg`, so the
header branding does not require an internet connection.

## Single-table jumbotron pages

Every connected table card includes a **Jumbotron** button. It opens a new
full-screen page for that table while the main dashboard stays open. Direct
links work for Tables 1 through 30, including before a table connects:

```text
http://PI_IP_ADDRESS:8081/?table=1
http://PI_IP_ADDRESS:8081/?table=30
```

The single-table page receives the same live score stream and retains the
browser-local Normal, Mirror, and 180° controls. Its **All tables** button
returns to the dashboard.

When a CYD reports a completed match, the table card automatically changes to
the full scorecard output: winner, both player rows, every saved game score,
and the final match result.

## TD admin score history

Open `http://PI_IP_ADDRESS:8081/admin.html` or select **TD Admin** on the main
dashboard. The server-protected login password defaults to `2580`. The page
shows the current score from every table and up to 5,000 time-stamped score
updates. Search by player, table, score, status, or displayed date/time, and use
the date and table filters to narrow the history quickly.

Completed current tables show their full scorecard. Completed entries in Score
History are highlighted; select the row or **View card** to reopen the complete
past-match scorecard.

The TD Admin footer displays the running application release, beginning with
`v1.6`. The same version is included in the server health and table API
responses.

For a different password, start the service with the
`SCOREKEEPER_ADMIN_PASSWORD` environment variable set. This is intended for a
trusted local tournament network; do not expose the unencrypted HTTP service
directly to the public internet.

## Install as a background service

Run `chmod +x install.sh`, then `./install.sh`. The service starts automatically whenever the Pi boots.

Scores, assignments, and remembered names are stored in `~/.local/share/scorekeeper-hub/scorekeeper.db`. The installer migrates the database from the currently installed version folder on the first v1.6 installation. Back up that shared file to preserve the event log.
