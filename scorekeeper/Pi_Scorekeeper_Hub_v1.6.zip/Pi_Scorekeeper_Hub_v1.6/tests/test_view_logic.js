#!/usr/bin/env node
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');

const html = fs.readFileSync(new URL('../static/index.html', `file://${__filename}`), 'utf8');
const script = html.match(/<script>([\s\S]*?)<\/script>/)[1];
const elements = new Map();

function element(selector) {
  if (!elements.has(selector)) {
    elements.set(selector, {
      innerHTML: '',
      textContent: '',
      addEventListener() {},
    });
  }
  return elements.get(selector);
}

class EventSourceStub {
  addEventListener() {}
}

const context = vm.createContext({
  console,
  URLSearchParams,
  location: { search: '' },
  localStorage: { getItem() { return null; }, setItem() {} },
  document: {
    title: '',
    body: { classList: { add() {} } },
    querySelector: element,
  },
  EventSource: EventSourceStub,
  fetch: async () => ({ json: async () => ({ tables: [] }) }),
  setInterval() {},
});

vm.runInContext(`${script}\n;globalThis.__test={gamePips,playerStates,displayPlayers,completedScorecard,state,tableViews,render};`, context);
const view = context.__test;

const table = {
  table: 7,
  player1: 'Red Riley',
  player2: 'Blue Betty',
  score1: 5,
  score2: 4,
  games1: 2,
  games2: 1,
  gameNumber: 4,
  bestOf: 7,
  timeoutUsed1: false,
  timeoutUsed2: true,
  leftPlayer: 0,
  gameType: 'standard_match',
  elapsedSeconds: 90,
  status: 'playing',
  gameScores: [[7, 4], [5, 7], [7, 3]],
  updatedAt: new Date().toISOString(),
};

assert.deepEqual(Array.from(view.displayPlayers(table, 'normal'), p => p.id), [1, 2]);
assert.deepEqual(Array.from(view.displayPlayers(table, 'mirror'), p => p.id), [2, 1]);
assert.deepEqual(Array.from(view.displayPlayers({ ...table, leftPlayer: 1 }, 'normal'), p => p.id), [2, 1]);
assert.deepEqual(Array.from(view.displayPlayers({ ...table, leftPlayer: 1 }, 'mirror'), p => p.id), [1, 2]);
assert.deepEqual(Array.from(view.displayPlayers(table, 'rotate'), p => p.id), [1, 2]);

const redPips = view.gamePips(2, 'p1');
const bluePips = view.gamePips(1, 'p2');
assert.match(redPips, /game-pips p1/);
assert.equal((redPips.match(/class="game-pip"/g) || []).length, 2);
assert.match(redPips, /aria-label="2 games won"/);
assert.match(bluePips, /game-pips p2/);
assert.equal((bluePips.match(/class="game-pip"/g) || []).length, 1);

view.state.set(table.table, table);
view.tableViews[table.table] = 'mirror';
view.render();
const mirrored = element('#grid').innerHTML;
assert.match(mirrored, /data-view="mirror"/);
assert.match(mirrored, /data-player="2"[\s\S]*?Blue Betty[\s\S]*?game-pips p2[\s\S]*?aria-label="1 game won"[\s\S]*?data-player="1"[\s\S]*?Red Riley[\s\S]*?game-pips p1[\s\S]*?aria-label="2 games won"/);

view.state.set(table.table, { ...table, leftPlayer: 1 });
view.tableViews[table.table] = 'normal';
view.render();
const swapped = element('#grid').innerHTML;
assert.match(swapped, /data-player="2"[\s\S]*?Blue Betty[\s\S]*?game-pips p2[\s\S]*?aria-label="1 game won"[\s\S]*?data-player="1"[\s\S]*?Red Riley[\s\S]*?game-pips p1[\s\S]*?aria-label="2 games won"/);

view.tableViews[table.table] = 'rotate';
view.render();
assert.match(element('#grid').innerHTML, /data-view="rotate"[\s\S]*?game-pips p2[\s\S]*?game-pips p1/);

const complete = view.completedScorecard({ ...table, status: 'complete' });
assert.match(complete, /scorecard-row winner p1[\s\S]*?Red Riley[\s\S]*?aria-label="2 games won"/);
assert.match(complete, /scorecard-row  p2[\s\S]*?Blue Betty[\s\S]*?aria-label="1 game won"/);

view.state.set(table.table, { ...table, status: 'complete', gameScores: [] });
view.tableViews[table.table] = 'normal';
view.render();
const completeWithoutScores = element('#grid').innerHTML;
assert.match(completeWithoutScores, /MATCH CARD RESULT/);
assert.match(completeWithoutScores, /Red Riley[\s\S]*?aria-label="2 games won"/);
assert.match(completeWithoutScores, /Blue Betty[\s\S]*?aria-label="1 game won"/);
assert.match(completeWithoutScores, /Individual game scores not reported/);

console.log('PASS: player identity, pip color class, pip count, side swap, mirror, rotate, and completed scorecard');
