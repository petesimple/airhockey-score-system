#!/usr/bin/env python3
import importlib.util
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def load_server():
    spec = importlib.util.spec_from_file_location("scorekeeper_server", ROOT / "server.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class VersionAndProjectTests(unittest.TestCase):
    def test_version_is_consistent(self):
        server = load_server()
        self.assertEqual(server.APP_VERSION, "v1.6")
        self.assertEqual((ROOT / "VERSION").read_text().strip(), "v1.6")
        admin = (ROOT / "static" / "admin.html").read_text()
        self.assertIn("7-6 SCOREKEEPER HUB", admin)
        self.assertIn("Application version v1.6", admin)
        self.assertIn("<strong>v1.6</strong>", admin)

    def test_complete_project_files_exist(self):
        required = [
            "server.py",
            "install.sh",
            "README.md",
            "VERSION",
            "static/index.html",
            "static/admin.html",
            "static/admin-login.html",
            "static/matches.html",
            "static/logo.svg",
            "cyd_firmware/CYD_Scorekeeper_v1_6.ino",
            "cyd_firmware/scorekeeper_logo.h",
            "cyd_firmware/README.md",
        ]
        for relative in required:
            self.assertTrue((ROOT / relative).is_file(), relative)

    def test_installer_restarts_existing_service_on_upgrade(self):
        installer = (ROOT / "install.sh").read_text()
        self.assertIn("systemctl enable scorekeeper-hub", installer)
        self.assertIn("systemctl restart scorekeeper-hub", installer)
        self.assertIn("SCOREKEEPER_DB", installer)
        self.assertIn(".local/share/scorekeeper-hub", installer)

    def test_player_game_state_protocol_remains_compatible(self):
        server = load_server()
        cleaned = server.clean_payload({
            "table": 1,
            "deviceId": "cyd-1",
            "player1": "Red Player",
            "player2": "Blue Player",
            "games1": 2,
            "games2": 1,
            "status": "complete",
            "leftPlayer": 1,
        })
        self.assertEqual(cleaned["games1"], 2)
        self.assertEqual(cleaned["games2"], 1)
        self.assertEqual(cleaned["leftPlayer"], 1)
        self.assertNotIn("pips", cleaned)
        self.assertEqual(cleaned["scoreSummary"], "")

    def test_game_score_summary_is_stored(self):
        server = load_server()
        cleaned = server.clean_payload({
            "table": 2, "deviceId": "cyd-2", "player1": "A", "player2": "B",
            "status": "complete", "gameScores": [[7, 4], [5, 7], [7, 6]],
        })
        self.assertEqual(cleaned["gameScores"], [[7, 4], [5, 7], [7, 6]])
        self.assertEqual(cleaned["scoreSummary"], "G1 7-4 | G2 5-7 | G3 7-6")

    def test_match_assignment_aliases_and_validation(self):
        server = load_server()
        cleaned = server.clean_assignment({
            "tableNumber": 4, "redPlayer": " Alice ", "bluePlayer": "Bob",
            "match_id": "R2-M4", "best_of": 5,
        })
        self.assertEqual(cleaned, {
            "table": 4, "player1": "Alice", "player2": "Bob", "matchId": "R2-M4",
            "bestOf": 5, "source": "external", "referee": "", "openUrl": "",
        })
        with self.assertRaises(ValueError):
            server.clean_assignment({"table": 31, "player1": "A", "player2": "B"})
        with self.assertRaises(ValueError):
            server.clean_assignment({"table": 1, "player1": "A", "player2": ""})

    def test_assignments_persist_names_revise_and_acknowledge(self):
        server = load_server()
        with tempfile.TemporaryDirectory() as folder:
            server.DB_PATH = Path(folder) / "test.db"
            server.initialize()
            self.assertEqual(server.assignment_snapshot(), [])
            with server.db() as connection:
                routes = connection.execute("SELECT * FROM table_devices").fetchall()
            self.assertEqual(routes, [])
            first = server.save_assignments({"table": 1, "player1": "Alice", "player2": "Bob"})[0]
            self.assertEqual(first["revision"], 1)
            second = server.save_assignments({"matches": [{
                "table": 1, "player1": "Alice", "player2": "Carol", "source": "chart-x"
            }]})[0]
            self.assertEqual(second["revision"], 2)
            current = server.assignment_snapshot(1)[0]
            self.assertEqual(current["player2"], "Carol")
            self.assertFalse(current["received"])
            names = {item["name"] for item in server.remembered_names()}
            self.assertEqual(names, {"Alice", "Bob", "Carol"})
            server.acknowledge_assignment({"table": 1, "revision": 2, "deviceId": "cyd-1"})
            received = server.assignment_snapshot(1)[0]
            self.assertTrue(received["received"])
            self.assertEqual(received["receivedBy"], "cyd-1")
            self.assertTrue(server.delete_assignment(1))
            self.assertEqual(server.assignment_snapshot(1), [])

    def test_current_td_payload_fields_remain_compatible(self):
        server = load_server()
        assignment = server.clean_assignment({
            "table": "3", "p1": "Player A", "p2": "Player B", "matchType": "Best of 7",
            "matchId": "weeklyABCD-2026-09-14", "referee": "Pete", "deviceIp": "192.168.1.33",
            "scoreboardUrl": "https://example.test/score?p1=Player%20A&p2=Player%20B",
        }, "td-app")
        self.assertEqual(assignment["bestOf"], 7)
        self.assertEqual(assignment["source"], "td-app")
        self.assertEqual(assignment["player1"], "Player A")
        self.assertEqual(assignment["player2"], "Player B")
        self.assertEqual(assignment["matchId"], "weeklyABCD-2026-09-14")
        self.assertEqual(assignment["referee"], "Pete")
        self.assertEqual(assignment["openUrl"], "https://example.test/score?p1=Player%20A&p2=Player%20B")
        self.assertNotIn("deviceIp", assignment)

    def test_remembered_names_can_be_renamed_deleted_and_cleared(self):
        server = load_server()
        with tempfile.TemporaryDirectory() as folder:
            server.DB_PATH = Path(folder) / "test.db"
            server.initialize()
            with server.db() as connection:
                connection.execute("INSERT INTO player_names(name,last_used_at) VALUES ('Alice',?)", (server.now_iso(),))
                connection.execute("INSERT INTO player_names(name,last_used_at) VALUES ('Bob',?)", (server.now_iso(),))
            renamed = server.manage_remembered_name({"action": "rename", "oldName": "Alice", "newName": "Alicia"})
            self.assertEqual({item["name"] for item in renamed["playerNames"]}, {"Alicia", "Bob"})
            deleted = server.manage_remembered_name({"action": "delete", "name": "Bob"})
            self.assertEqual([item["name"] for item in deleted["playerNames"]], ["Alicia"])
            cleared = server.manage_remembered_name({"action": "clear"})
            self.assertEqual(cleared["changed"], 1)
            self.assertEqual(cleared["playerNames"], [])

    def test_cyd_retrieves_by_table_and_completion_clears_assignment(self):
        server = load_server()
        with tempfile.TemporaryDirectory() as folder:
            server.DB_PATH = Path(folder) / "test.db"
            server.initialize()
            assignment = server.save_assignments({
                "table": 2, "player1": "A", "player2": "B", "bestOf": 5,
            })[0]
            match = server.retrieve_assignment(2, "AA:BB:CC:DD:EE:FF", "10.42.0.77")
            self.assertEqual(match["revision"], assignment["revision"])
            self.assertTrue(match["received"])
            self.assertEqual(match["receivedBy"], "AA:BB:CC:DD:EE:FF")
            self.assertEqual(match["deliveryStatus"], "received")
            with server.db() as connection:
                device = connection.execute(
                    "SELECT device_id,ip_address FROM table_devices WHERE table_number=2"
                ).fetchone()
            self.assertEqual(device["device_id"], "AA:BB:CC:DD:EE:FF")
            self.assertEqual(device["ip_address"], "10.42.0.77")

            complete = server.clean_payload({
                "table": 2, "deviceId": "AA:BB:CC:DD:EE:FF", "player1": "A", "player2": "B",
                "games1": 3, "games2": 1, "bestOf": 5, "status": "complete",
            })
            server.save_update(complete)
            self.assertEqual(server.assignment_snapshot(2), [])


if __name__ == "__main__":
    unittest.main()
