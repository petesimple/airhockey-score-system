#!/usr/bin/env python3
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
FIRMWARE = ROOT / "cyd_firmware" / "CYD_Scorekeeper_v1_6.ino"


class CydFirmwareTests(unittest.TestCase):
    def test_firmware_uses_table_polling_and_lan_discovery(self):
        source = FIRMWARE.read_text()
        self.assertIn('#include <WiFiUdp.h>', source)
        self.assertIn('SCOREKEEPER_HUB_DISCOVER', source)
        self.assertIn('SCOREKEEPER_DISCOVERY_PORT=8082', source)
        self.assertIn('/api/matches/table/', source)
        self.assertIn('?deviceId=', source)
        self.assertIn('String hubIP=""', source)
        self.assertNotIn('10.0.0.53', source)
        self.assertNotIn(':7070/open', source)

    def test_td_google_feed_remains_as_fallback(self):
        source = FIRMWARE.read_text()
        hub_fetch = source.index('if(fetchHubAssignment(false))return true;')
        cloud_fetch = source.index('HTTPClient http; http.begin(DATA_URL);')
        self.assertLess(hub_fetch, cloud_fetch)
        self.assertIn('publicBracketGet', source)


if __name__ == "__main__":
    unittest.main()
